from django.shortcuts import render, get_object_or_404
from blog.models import Post

# Create your views here.
def allpost(request):
    pst = Post.objects.all()
    print(pst[0].image)
    return render(request,'post.html',{'post':pst})
def detail(request,blog_id):
    detail = get_object_or_404(Post,pk = blog_id)
    return render(request,'detail.html', {'pst':detail})